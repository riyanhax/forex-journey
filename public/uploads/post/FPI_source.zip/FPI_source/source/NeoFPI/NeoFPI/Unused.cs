//using NeoTicker;
//namespace NeoKreslik
//{
//    class UnusuedCode
//    {
//        ParamListObj Params = _NeoObjects.Params();

//        DrawingObjectsObj MyChartDrawingObj = _NeoObjects.ChartDrawingObjects();
//        DrawingObjectsObj MyDrawingObj = _NeoObjects.DrawingObjects();


//        TradeObj MyTradeObj = _NeoObjects.Trade();
//        ReportObj MyReportObj = _NeoObjects.Report();

//        HeapObj MyHeapObj = _NeoObjects.Heap();
//        HeapObj MyPHeapObj = _NeoObjects.Heap();
//        HeapObj MyGHeapObj = _NeoObjects.GHeap();

//        NTLibObj MyNTLibObj = _NeoObjects.NTLib();
//        ExcelObj MyExcelObj = _NeoObjects.Excel();
//        LinkSeriesObj MyLinkSeriesObj = _NeoObjects.LinkSeries();

//        ParamListObj Params = _NeoObjects.Params();
//        this.labelDataStreamFromInput.Text = Params.get_Items("stream").Int.ToString();

//        private void button2_Click(object sender, EventArgs e)
//        {
//            App MyNeoTickerApp = new App();
//            MyNeoTickerApp.NewFunctionWindow("New Window", FWType.TimeChart);
//        }

//        double plot = MyDataStream[3].get_Close(0) * MyDataStream[5].get_Close(0) * (1 / MyDataStream[4].get_Close(0));
//        plot = (plot - 1)*100000;
//        Itself.set_Plot(1, plot);
//        Itself.set_Plot(2, 0);


//        DataSeriesObj MyDataSeriesObj;
//        DataObj[] MyDataStreamsArray;
//        string[] SymbolsArray;
//        MyDataSeriesObj = NeoObjects.DataSeries();
//        MyDataStreamsArray = new DataObj[MyDataSeriesObj.Count + 1]; // +1 since we don't want to reference the data stream 1 as [0]
//        SymbolsArray = new string[MyDataSeriesObj.Count];
//        for (int index = 1; index <= MyDataSeriesObj.Count; index++)
//        {
//            MyDataStreamsArray[index] = NeoObjects.DataSeries().get_Items(index);
//            SymbolsArray[index - 1] = MyDataStreamsArray[index].Symbol.ToString();
//        }

//        DataObj[] MyDataStream;
//        MyDataStream = new DataObj[NeoObjects.DataSeries().Count + 1]; // +1 since we don't want to reference the data stream 1 as [0]

//                    this.labelNumOfSymbolsOnChart.Text = NeoObjects.DataSeries().Count.ToString();

		
//        }
//    }




        //private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        //{
        //    if (AppSettings.DataStream != this.listBoxAllSym.SelectedIndex + 1)
        //    {
        //        AppSettings.DataStream = listBoxAllSym.SelectedIndex + 1;
        //        KToolsNeo.RefreshChart(ClassNeoObjects);
        //    }
//}



#region CalculateStrings
//public void CalculateRings(CalcRingsForm ParentForm)
        //{
        //    FPIRingsStringSymbols_Dynamic = new ArrayList();
        //    FPIRingsSymbolInRingFlags_Dynamic = new ArrayList();
        //    FPIMatrix.Initialize(FXUniqueSyms, FXUniqueCurrencies);
        //    ProgressChangedEventHandler ProgressChangedDelegate = new ProgressChangedEventHandler(ParentForm.ProgressChanged);
        //    double OnePercent = TotalCombinations / 100D; // 100 double
        //    int CurrentPercent = 0;

        //    for (ulong Combination = 0; Combination < TotalCombinations; Combination++)
        //    {
        //        if (FPIMatrix.TryCombination(Combination))
        //        {
        //            ArrayList FirstCurrencies = new ArrayList();
        //            ArrayList SecondCurrencies = new ArrayList();
        //            SymbolInRing[] SymbolsInRingFlags = new SymbolInRing[FXSymsCount];
        //            string SymbolsInRingString = "";
        //            int SymbolsInRingCount = 0;
        //            bool ThisCombinationIsValid = true;
        //            for (int fxsym = 0; fxsym < FXSymsCount; fxsym++)
        //            {
        //                if (FPIMatrix.LastCombinationBinary[fxsym] == '1')
        //                {
        //                    SymbolsInRingString += FXUniqueSyms[fxsym] + " ";
        //                    SymbolsInRingCount++;

        //                    bool SymbolCanBeUsedAsNorm = true;

        //                    for (int i = 0; i < FirstCurrencies.Count; i++) // we could use SecondCurrencies.Count as well
        //                    {
        //                        if ((string)FirstCurrencies[i] == KToolsFX.FirstCurrencyInFXSymbol(FXUniqueSyms[fxsym]) ||
        //                            (string)SecondCurrencies[i] == KToolsFX.SecondCurrencyInFXSymbol(FXUniqueSyms[fxsym]))
        //                        {
        //                            SymbolCanBeUsedAsNorm = false;
        //                        }
        //                    }
        //                    if (SymbolCanBeUsedAsNorm)
        //                    {
        //                        SymbolsInRingFlags[fxsym] = SymbolInRing.UsedNorm;
        //                        FirstCurrencies.Add(KToolsFX.FirstCurrencyInFXSymbol(FXUniqueSyms[fxsym]));
        //                        SecondCurrencies.Add(KToolsFX.SecondCurrencyInFXSymbol(FXUniqueSyms[fxsym]));
        //                    }
        //                    // symbol must be used as UsedRev, now let's check this reversion doesn't collide with symbols already in ring
        //                    // if yes, entire combination is invalid = it is not possible to construct a ring from these symbols
        //                    else
        //                    {
        //                        for (int i = 0; i < FirstCurrencies.Count; i++) // we could use SecondCurrencies.Count as well
        //                        {
        //                            if ((string)FirstCurrencies[i] == KToolsFX.SecondCurrencyInFXSymbol(FXUniqueSyms[fxsym]) ||
        //                                (string)SecondCurrencies[i] == KToolsFX.FirstCurrencyInFXSymbol(FXUniqueSyms[fxsym]))
        //                            {
        //                                ThisCombinationIsValid = false;
        //                            }
        //                        }
        //                        if (ThisCombinationIsValid)
        //                        {
        //                            SymbolsInRingFlags[fxsym] = SymbolInRing.UsedReversed;
        //                            FirstCurrencies.Add(KToolsFX.SecondCurrencyInFXSymbol(FXUniqueSyms[fxsym]));
        //                            SecondCurrencies.Add(KToolsFX.FirstCurrencyInFXSymbol(FXUniqueSyms[fxsym]));
        //                        }
        //                    }
        //                }
        //                else // this symbol is not used
        //                {
        //                    SymbolsInRingFlags[fxsym] = SymbolInRing.NotUsed;
        //                }
        //            }
        //            if (ThisCombinationIsValid)
        //            {
        //                FPIRingsStringSymbols_Dynamic.Add(SymbolsInRingCount.ToString() + ": " + SymbolsInRingString);
        //                FPIRingsSymbolInRingFlags_Dynamic.Add(SymbolsInRingFlags);
        //            }
        //        }

        //        if ((Combination + 1) / OnePercent > CurrentPercent) // we are starting from 0 internally
        //        {
        //            CurrentPercent = (int)((Combination + 1)/ OnePercent);
        //            ParentForm.Invoke(ProgressChangedDelegate, CurrentPercent);
        //        }
        //    }


        //    FPIRingsSymbols = new string[FPIRingsStringSymbols_Dynamic.Count];
        //    FPIRingsStringSymbols_Dynamic.CopyTo(FPIRingsSymbols);

        //    FPIRingsFlags = new object[FPIRingsSymbolInRingFlags_Dynamic.Count];
        //    FPIRingsSymbolInRingFlags_Dynamic.CopyTo(FPIRingsFlags);

        //    Array.Sort(FPIRingsSymbols, FPIRingsFlags);
        //    FPIRingsCount = FPIRingsSymbols.Length;
        //}
#endregion