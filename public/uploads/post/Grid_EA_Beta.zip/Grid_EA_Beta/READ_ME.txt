
Title: Grid_v5  	Currency Pair: EUR/USD      

Timeframe: H1		Lots Size: 0.01 to 2.74
			
Compatibility:	Only MT4
