
Title: Reverse_v2  	Currency Pair: EUR/USD      

Timeframe: H1		Lots Size: 0.01 to 3.77
			
Compatibility:	Only MT4