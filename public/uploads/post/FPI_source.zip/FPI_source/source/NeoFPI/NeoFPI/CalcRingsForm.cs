﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using KreslikLib.Common;

namespace NeoFPI
{
    public partial class CalcRingsForm : Form
    {
        CommonObject C;
        Thread MyCalcThread;

        public CalcRingsForm(CommonObject C)
        {
            InitializeComponent();

            this.C = C;

            this.btnOK.Visible = false;
            this.btnAbort.Enabled = true;
            this.btnAbort.Text = "Abort";
            this.btnAbort.Focus();
            this.btnBackToControl.Visible = false;
            this.lblCombTotal.Text = C.FPIObject.TotalCombinations.ToString();

            ThreadStart ThreadStartDelegate = new ThreadStart(CalculateRingsJob);
            MyCalcThread = new Thread(ThreadStartDelegate);
            MyCalcThread.Start();
        }

        private void CalculateRingsJob()
        {
            JobFinishedEventHandler JobFinishedOK = new JobFinishedEventHandler(JobFinishedWork);
            C.FPIObject.CalculateRings(this);
            this.Invoke(JobFinishedOK);
        }

        protected internal void ProgressChanged(int Percent)
        {
            this.lblPercProcessed.Text = Percent.ToString() + "%";
            this.progressBar.Value = Percent;
            Application.DoEvents();
        }

        protected internal void RingCountChanged(int RingCount)
        {
            this.lblRingsFound.Text = RingCount.ToString();
            Application.DoEvents();
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            this.btnAbort.Enabled = false;
            this.btnAbort.Text = "Aborting...";
            MyCalcThread.Abort();
            MyCalcThread.Join();
            this.btnAbort.Visible = false;
            this.btnBackToControl.Visible = true;
            this.btnBackToControl.Focus();
        }

        private delegate void JobFinishedEventHandler();
        private void JobFinishedWork()
        {
            this.btnAbort.Visible = false;
            this.btnOK.Visible = true;
            this.btnOK.Focus();
        }
    }
}