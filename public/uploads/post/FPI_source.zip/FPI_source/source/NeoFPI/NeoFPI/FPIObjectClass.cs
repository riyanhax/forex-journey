﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Windows.Forms;

using NeoTicker;
using KreslikLib.Neo;
using KreslikLib.Common;
using KreslikLib.Forex;

namespace NeoFPI
{
    /// <summary>
    /// Denotes whether this FX symbol is used in currency ring.
    /// NotUsed = not used
    /// UsedNorm = multiply by FX symbol quote
    /// UsedReversed = multiply by 1 / (FX symbol quote)
    /// </summary>
    public enum SymbolInRing
    {
        NotUsed,
        UsedNorm,
        UsedReversed
    }

    public class FPIObjectClass
    {
        internal string[] AllSymbolsOnChart;
        internal int[] AllSymbolsStreams;
        internal string[] AllSymbolsAndStreams;

        internal string[] FXUniqueSyms; // EUR/USD, GBP/USD, USD/CHF
        internal int[] FXUniqueStreams; // 2, 3, 5, 1
        internal string[] FXSymsAndStreams;
        internal int FXSymsCount;

        internal string[] FXUniqueCurrencies; // AUD, EUR, CHF...
        internal int FXUniqueCurrCount;
        internal string[] FXCurrencyNames; // Australian Dollar, Euro, ..
        internal string[] FXISOcodes; // 230, 352, 840..
        internal string[] FXCurrAndNames;

        internal string[] FPIRingsSymbols;
        internal object[] FPIRingsFlags;
        internal int FPIRingsCount = 0;
        internal int FPIRingSelected = -1;

        internal ulong TotalCombinations = 0;

        internal SymbolInRing[] FPIRingToPlot;

        PairsMatrixClass FPIMatrix;
        ArrayList FPIRingsStringSymbols_Dynamic;
        ArrayList FPIRingsSymbolInRingFlags_Dynamic;

        CommonObject C;

        public FPIObjectClass(CommonObject C)
        {
            this.C = C;
            FPIMatrix = new PairsMatrixClass();
        }
        
        public void Initialize(out bool AllSymStrmChanged, out bool FXSymStrmChanged, out bool FXCurrChanged)
        {
            KToolsNeo.ExtractSymbolsFromChart(C.N, SymbolType.AllSymbols, true, false, out AllSymbolsOnChart, out AllSymbolsStreams);
            
            KToolsNeo.ExtractSymbolsFromChart(C.N, SymbolType.ForexSymbols, false, true, out FXUniqueSyms, out FXUniqueStreams);

            FXUniqueCurrencies = KToolsFX.ExtractUniqueCurrenciesFromFXSymbols(FXUniqueSyms);
            FXUniqueCurrCount = FXUniqueCurrencies.Length;
            FXSymsCount = FXUniqueSyms.Length;

            ArrayList FXCurrencyNamesArrayList = new ArrayList();
            ArrayList FXISOcodesArrayList = new ArrayList();
            FXCurrencies MyFX = new FXCurrencies();
            foreach (string CurrencyAlphaCode in FXUniqueCurrencies)
            {
                FXCurrencyNamesArrayList.Add(MyFX.CurrencyName(MyFX.IndexOfAlphanumericCode(CurrencyAlphaCode)));
                FXISOcodesArrayList.Add(MyFX.NumericCode(MyFX.IndexOfAlphanumericCode(CurrencyAlphaCode)).ToString());
            }
            FXCurrencyNames = new string[FXCurrencyNamesArrayList.Count]; FXCurrencyNamesArrayList.CopyTo(FXCurrencyNames, 0);
            FXISOcodes = new string[FXISOcodesArrayList.Count]; FXISOcodesArrayList.CopyTo(FXISOcodes, 0);

            KTools.ConcatenateArrays(ref AllSymbolsAndStreams, out AllSymStrmChanged, AllSymbolsOnChart, ": ", AllSymbolsStreams);
            KTools.ConcatenateArrays(ref FXSymsAndStreams, out FXSymStrmChanged, FXUniqueSyms, ": ", FXUniqueStreams);
            KTools.ConcatenateArrays(ref FXCurrAndNames, out FXCurrChanged, FXUniqueCurrencies, ": ", FXCurrencyNames, ", ", FXISOcodes);

            TotalCombinations = KTools.Power(2, FXSymsCount);
        }

        public void ResetSymbolsAndCurrencies()
        {
            AllSymbolsAndStreams = null;
            FXSymsAndStreams = null;
            FXCurrAndNames = null;
        }

        public void SetFPIRingToPlot(int FPIRingID)
        {
            if (FPIRingsCount > 0 && FPIRingID < FPIRingsCount)
            {
                FPIRingToPlot = (SymbolInRing[])FPIRingsFlags[FPIRingID];
                FPIRingSelected = FPIRingID;
            }
        }

        private delegate void ProgressChangedEventHandler(int Percent);
        private delegate void RingCountChangedEventHandler(int RingCount);
        public void CalculateRings(CalcRingsForm ParentForm)
        {
            FPIMatrix.Initialize(C);

            FPIRingsStringSymbols_Dynamic = new ArrayList();
            FPIRingsSymbolInRingFlags_Dynamic = new ArrayList();
            ProgressChangedEventHandler ProgressChangedDelegate = new ProgressChangedEventHandler(ParentForm.ProgressChanged);
            RingCountChangedEventHandler RingCountChangedDelegate = new RingCountChangedEventHandler(ParentForm.RingCountChanged);
            double OnePercent = TotalCombinations / 100D; // 100 double
            int CurrentPercent = 0;
            ParentForm.Invoke(RingCountChangedDelegate, 0);

            // I am using ulong since the number of combinations may easily exceed the max value of int
            for (ulong Combination = 1; Combination <= TotalCombinations; Combination++)
            {
                int SymbolsUsed = SymbolsInCombination(FPIMatrix.DecimalToStringBin(Combination, FXSymsCount));

                if (SymbolsUsed > 2) // no reason for testing 2 or less FX symbols for rings
                {
                    if (FPIMatrix.TryCombination(Combination))
                    {
                        SymbolInRing[] SymbolsInRingFlags = KTools.InitializeArray(FXSymsCount, SymbolInRing.NotUsed);
                        bool[] FXSymAssigned = KTools.InitializeArray(FXSymsCount, false);
                        string SymbolsInRingString = "";
                        string LastAssignedSym = "";
                        int FirstSymInRing = 1; // used to determine whether we are assigning the first symbol in ring = no check for symbol tie
                        bool ThisCombinationIsValid = true;

                        for (int i = 0; i < SymbolsUsed && ThisCombinationIsValid; i++)
                        {
                            bool Found = false;
                            int FXSymID = 0;
                            bool Reversed = true;
                            string CurrentSymbol;
                            do
                            {
                                CurrentSymbol = FXUniqueSyms[FXSymID];
                                if   // this symbol is used in a ring:
                                    (FPIMatrix.LastCombinationBinary[FXSymID] == '1'

                                    // && this symbol is not yet assigned the SymbolInRing value:
                                    && FXSymAssigned[FXSymID] == false

                                    // && this symbol is either a first symbol in ring OR a tie to the last assigned symbol:
                                    && (FirstSymInRing++ == 1 || KToolsFX.AtLeastOneCurrMatches(CurrentSymbol, LastAssignedSym, out Reversed)))
                                {
                                    if (Reversed)
                                    {
                                        LastAssignedSym = CurrentSymbol;
                                        SymbolsInRingString += CurrentSymbol + " ";
                                        SymbolsInRingFlags[FXSymID] = SymbolInRing.UsedNorm;
                                    }
                                    else // the currencies in the two FX symbols are not reversed, so we have to reverse them
                                    {
                                        LastAssignedSym = KToolsFX.ReverseCurrenciesInFXSymbol(CurrentSymbol);
                                        SymbolsInRingString += "(" + CurrentSymbol + ") ";
                                        SymbolsInRingFlags[FXSymID] = SymbolInRing.UsedReversed;
                                    }

                                    FXSymAssigned[FXSymID] = true;
                                    Found = true;
                                }

                                FXSymID++;
                                if (Found == false && FXSymID == FXUniqueSyms.Length)
                                {
                                    // if no tie is found, it means there are more than one valid rings in the matrix, so we invalidate this combination
                                    ThisCombinationIsValid = false;
                                }
                            } while (!Found && ThisCombinationIsValid);
                        }

                        if (ThisCombinationIsValid)
                        {
                            FPIRingsStringSymbols_Dynamic.Add(SymbolsUsed.ToString() + " symbols: " + SymbolsInRingString);
                            FPIRingsSymbolInRingFlags_Dynamic.Add(SymbolsInRingFlags);
                            ParentForm.Invoke(RingCountChangedDelegate, FPIRingsSymbolInRingFlags_Dynamic.Count);
                        }
                    }
                }

                if ((Combination) / OnePercent > CurrentPercent)
                {
                    CurrentPercent = (int)((Combination)/ OnePercent);
                    ParentForm.Invoke(ProgressChangedDelegate, CurrentPercent);
                }
            }


            KTools.ConvertArrayListToArray<string>(FPIRingsStringSymbols_Dynamic, out FPIRingsSymbols);
            KTools.ConvertArrayListToArray<object>(FPIRingsSymbolInRingFlags_Dynamic, out FPIRingsFlags);

            Array.Sort(FPIRingsSymbols, FPIRingsFlags);
            FPIRingsCount = FPIRingsSymbols.Length;
        }

        private int SymbolsInCombination(string BinaryCombination)
        {
            int Result = 0;
            for (int i = 0; i < BinaryCombination.Length; i++)
            {
                if (BinaryCombination[i] == '1')
                {
                    Result++;
                }
            }
            return Result;
        }
    }
}