using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace KreslikLib.Forex
{
    public enum BarPrice
    {
        Open,
        High,
        Low,
        Close
    }


}