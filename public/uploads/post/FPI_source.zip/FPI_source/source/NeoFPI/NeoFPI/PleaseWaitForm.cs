﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NeoFPI
{
    public partial class PleaseWaitForm : Form
    {
        CommonObject C;

        public PleaseWaitForm(CommonObject C)
        {
            this.C = C;
            InitializeComponent();
        }

        internal void CloseWaitForm()
        {
            InvokeDelegate CloseFormD = new InvokeDelegate(CloseForm);
            this.Invoke(CloseFormD);
        }

        void CloseForm()
        {
            this.Close();
        }
    }
}