﻿namespace NeoFPI
{
    partial class CalcRingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CalcRingsForm));
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCombTotal = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPercProcessed = new System.Windows.Forms.Label();
            this.btnAbort = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnBackToControl = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblRingsFound = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(12, 96);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(288, 23);
            this.progressBar.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Combinations total:";
            // 
            // lblCombTotal
            // 
            this.lblCombTotal.AutoSize = true;
            this.lblCombTotal.Location = new System.Drawing.Point(175, 13);
            this.lblCombTotal.Name = "lblCombTotal";
            this.lblCombTotal.Size = new System.Drawing.Size(35, 13);
            this.lblCombTotal.TabIndex = 2;
            this.lblCombTotal.Text = "label2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Combinations processed:";
            // 
            // lblPercProcessed
            // 
            this.lblPercProcessed.AutoSize = true;
            this.lblPercProcessed.Location = new System.Drawing.Point(175, 38);
            this.lblPercProcessed.Name = "lblPercProcessed";
            this.lblPercProcessed.Size = new System.Drawing.Size(35, 13);
            this.lblPercProcessed.TabIndex = 4;
            this.lblPercProcessed.Text = "label3";
            // 
            // btnAbort
            // 
            this.btnAbort.Location = new System.Drawing.Point(211, 136);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Size = new System.Drawing.Size(89, 23);
            this.btnAbort.TabIndex = 0;
            this.btnAbort.Text = "Abort";
            this.btnAbort.UseVisualStyleBackColor = true;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(211, 136);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(89, 23);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnBackToControl
            // 
            this.btnBackToControl.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBackToControl.Location = new System.Drawing.Point(158, 136);
            this.btnBackToControl.Name = "btnBackToControl";
            this.btnBackToControl.Size = new System.Drawing.Size(142, 23);
            this.btnBackToControl.TabIndex = 2;
            this.btnBackToControl.Text = "Back to Control Panel";
            this.btnBackToControl.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Rings found:";
            // 
            // lblRingsFound
            // 
            this.lblRingsFound.AutoSize = true;
            this.lblRingsFound.Location = new System.Drawing.Point(175, 63);
            this.lblRingsFound.Name = "lblRingsFound";
            this.lblRingsFound.Size = new System.Drawing.Size(35, 13);
            this.lblRingsFound.TabIndex = 9;
            this.lblRingsFound.Text = "label4";
            // 
            // CalcRingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 177);
            this.Controls.Add(this.lblRingsFound);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnBackToControl);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnAbort);
            this.Controls.Add(this.lblPercProcessed);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblCombTotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.progressBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CalcRingsForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Calculate Rings";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCombTotal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPercProcessed;
        private System.Windows.Forms.Button btnAbort;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnBackToControl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblRingsFound;
    }
}