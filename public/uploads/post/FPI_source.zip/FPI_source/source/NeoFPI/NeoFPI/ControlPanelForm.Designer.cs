﻿using System.IO;

namespace NeoFPI
{
    partial class ControlPanelForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ControlPanelForm));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.checkBoxTop = new System.Windows.Forms.CheckBox();
            this.lblVer = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.lblEnabled = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ListBoxFPIRings = new System.Windows.Forms.ListBox();
            this.lblFPIRings = new System.Windows.Forms.Label();
            this.btnCalcFPI = new System.Windows.Forms.Button();
            this.radioClose = new System.Windows.Forms.RadioButton();
            this.radioOpen = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblFXCurrCount = new System.Windows.Forms.Label();
            this.ListBoxFXCurrAndNames = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFXSymsCount = new System.Windows.Forms.Label();
            this.ListBox_FXSymsAndStreams = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblAllSymsCount = new System.Windows.Forms.Label();
            this.ListBox_AllSymsAndStreams = new System.Windows.Forms.ListBox();
            this.toolTipControlPanel = new System.Windows.Forms.ToolTip(this.components);
            this.statusStrip1.SuspendLayout();
            this.toolStripContainer1.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(775, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 20;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // statusLabel
            // 
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(42, 17);
            this.statusLabel.Text = "Ready.";
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.BottomToolStripPanel
            // 
            this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.statusStrip1);
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.AutoScroll = true;
            this.toolStripContainer1.ContentPanel.Controls.Add(this.pictureBox1);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.groupBox10);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.groupBox4);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.groupBox3);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.groupBox2);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.groupBox1);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(775, 640);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.LeftToolStripPanelVisible = false;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.RightToolStripPanelVisible = false;
            this.toolStripContainer1.Size = new System.Drawing.Size(775, 662);
            this.toolStripContainer1.TabIndex = 23;
            this.toolStripContainer1.Text = "toolStripContainer1";
            this.toolStripContainer1.TopToolStripPanelVisible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 126);
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label12);
            this.groupBox10.Controls.Add(this.checkBoxTop);
            this.groupBox10.Controls.Add(this.lblVer);
            this.groupBox10.Controls.Add(this.linkLabel2);
            this.groupBox10.Controls.Add(this.lblEnabled);
            this.groupBox10.Controls.Add(this.label1);
            this.groupBox10.Location = new System.Drawing.Point(128, 12);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(203, 126);
            this.groupBox10.TabIndex = 34;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "FPI Control Panel";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Version:";
            // 
            // checkBoxTop
            // 
            this.checkBoxTop.AutoSize = true;
            this.checkBoxTop.Location = new System.Drawing.Point(14, 45);
            this.checkBoxTop.Name = "checkBoxTop";
            this.checkBoxTop.Size = new System.Drawing.Size(80, 17);
            this.checkBoxTop.TabIndex = 33;
            this.checkBoxTop.Text = "Stay on top";
            this.checkBoxTop.UseVisualStyleBackColor = true;
            this.checkBoxTop.CheckedChanged += new System.EventHandler(this.checkBoxTop_CheckedChanged);
            // 
            // lblVer
            // 
            this.lblVer.AutoSize = true;
            this.lblVer.Location = new System.Drawing.Point(62, 20);
            this.lblVer.Name = "lblVer";
            this.lblVer.Size = new System.Drawing.Size(33, 13);
            this.lblVer.TabIndex = 0;
            this.lblVer.Text = "lblVer";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(11, 99);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(175, 13);
            this.linkLabel2.TabIndex = 32;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Go to kreslik.com discussion on FPI";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // lblEnabled
            // 
            this.lblEnabled.AutoSize = true;
            this.lblEnabled.Location = new System.Drawing.Point(168, 74);
            this.lblEnabled.Name = "lblEnabled";
            this.lblEnabled.Size = new System.Drawing.Size(17, 13);
            this.lblEnabled.TabIndex = 38;
            this.lblEnabled.Text = "lbl";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 13);
            this.label1.TabIndex = 36;
            this.label1.Text = "FPI Indicator Enabled:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ListBoxFPIRings);
            this.groupBox4.Controls.Add(this.lblFPIRings);
            this.groupBox4.Controls.Add(this.btnCalcFPI);
            this.groupBox4.Controls.Add(this.radioClose);
            this.groupBox4.Controls.Add(this.radioOpen);
            this.groupBox4.Location = new System.Drawing.Point(337, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(426, 614);
            this.groupBox4.TabIndex = 31;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "FPI Rings";
            // 
            // ListBoxFPIRings
            // 
            this.ListBoxFPIRings.FormattingEnabled = true;
            this.ListBoxFPIRings.HorizontalScrollbar = true;
            this.ListBoxFPIRings.Location = new System.Drawing.Point(12, 52);
            this.ListBoxFPIRings.Name = "ListBoxFPIRings";
            this.ListBoxFPIRings.Size = new System.Drawing.Size(402, 524);
            this.ListBoxFPIRings.TabIndex = 18;
            this.ListBoxFPIRings.SelectedIndexChanged += new System.EventHandler(this.ListBoxFPIRings_SelectedIndexChanged);
            // 
            // lblFPIRings
            // 
            this.lblFPIRings.AutoSize = true;
            this.lblFPIRings.Location = new System.Drawing.Point(151, 25);
            this.lblFPIRings.Name = "lblFPIRings";
            this.lblFPIRings.Size = new System.Drawing.Size(60, 13);
            this.lblFPIRings.TabIndex = 19;
            this.lblFPIRings.Text = "lblFPIRings";
            // 
            // btnCalcFPI
            // 
            this.btnCalcFPI.Location = new System.Drawing.Point(11, 20);
            this.btnCalcFPI.Name = "btnCalcFPI";
            this.btnCalcFPI.Size = new System.Drawing.Size(134, 23);
            this.btnCalcFPI.TabIndex = 26;
            this.btnCalcFPI.Text = "Calculate FPI Rings";
            this.btnCalcFPI.UseVisualStyleBackColor = true;
            this.btnCalcFPI.Click += new System.EventHandler(this.CalculateRings_click);
            // 
            // radioClose
            // 
            this.radioClose.AutoSize = true;
            this.radioClose.Enabled = false;
            this.radioClose.Location = new System.Drawing.Point(69, 582);
            this.radioClose.Name = "radioClose";
            this.radioClose.Size = new System.Drawing.Size(51, 17);
            this.radioClose.TabIndex = 25;
            this.radioClose.TabStop = true;
            this.radioClose.Text = "Close";
            this.toolTipControlPanel.SetToolTip(this.radioClose, "FPI is calculated from the prices that occur at the same time. Thus, we can\'t use" +
                    " bar\'s High nor Low.");
            this.radioClose.UseVisualStyleBackColor = true;
            this.radioClose.CheckedChanged += new System.EventHandler(this.RadioButtonsCheckChanged);
            // 
            // radioOpen
            // 
            this.radioOpen.AutoSize = true;
            this.radioOpen.Enabled = false;
            this.radioOpen.Location = new System.Drawing.Point(12, 582);
            this.radioOpen.Name = "radioOpen";
            this.radioOpen.Size = new System.Drawing.Size(51, 17);
            this.radioOpen.TabIndex = 25;
            this.radioOpen.TabStop = true;
            this.radioOpen.Text = "Open";
            this.toolTipControlPanel.SetToolTip(this.radioOpen, "FPI is calculated from the prices that occur at the same time. Thus, we can\'t use" +
                    " bar\'s High nor Low.");
            this.radioOpen.UseVisualStyleBackColor = true;
            this.radioOpen.CheckedChanged += new System.EventHandler(this.RadioButtonsCheckChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.lblFXCurrCount);
            this.groupBox3.Controls.Add(this.ListBoxFXCurrAndNames);
            this.groupBox3.Location = new System.Drawing.Point(12, 401);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(319, 225);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Unique FX Currencies on Chart, Name, ISO Code";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Count:";
            // 
            // lblFXCurrCount
            // 
            this.lblFXCurrCount.AutoSize = true;
            this.lblFXCurrCount.Location = new System.Drawing.Point(59, 20);
            this.lblFXCurrCount.Name = "lblFXCurrCount";
            this.lblFXCurrCount.Size = new System.Drawing.Size(13, 13);
            this.lblFXCurrCount.TabIndex = 11;
            this.lblFXCurrCount.Text = "0";
            // 
            // ListBoxFXCurrAndNames
            // 
            this.ListBoxFXCurrAndNames.FormattingEnabled = true;
            this.ListBoxFXCurrAndNames.Location = new System.Drawing.Point(12, 39);
            this.ListBoxFXCurrAndNames.Name = "ListBoxFXCurrAndNames";
            this.ListBoxFXCurrAndNames.Size = new System.Drawing.Size(295, 173);
            this.ListBoxFXCurrAndNames.TabIndex = 10;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.lblFXSymsCount);
            this.groupBox2.Controls.Add(this.ListBox_FXSymsAndStreams);
            this.groupBox2.Location = new System.Drawing.Point(175, 146);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(156, 249);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Unique FX Symbols on Chart";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Count:";
            // 
            // lblFXSymsCount
            // 
            this.lblFXSymsCount.AutoSize = true;
            this.lblFXSymsCount.Location = new System.Drawing.Point(59, 20);
            this.lblFXSymsCount.Name = "lblFXSymsCount";
            this.lblFXSymsCount.Size = new System.Drawing.Size(13, 13);
            this.lblFXSymsCount.TabIndex = 10;
            this.lblFXSymsCount.Text = "0";
            // 
            // ListBox_FXSymsAndStreams
            // 
            this.ListBox_FXSymsAndStreams.FormattingEnabled = true;
            this.ListBox_FXSymsAndStreams.Location = new System.Drawing.Point(12, 39);
            this.ListBox_FXSymsAndStreams.Name = "ListBox_FXSymsAndStreams";
            this.ListBox_FXSymsAndStreams.Size = new System.Drawing.Size(132, 199);
            this.ListBox_FXSymsAndStreams.TabIndex = 9;
            this.ListBox_FXSymsAndStreams.SelectedIndexChanged += new System.EventHandler(this.ListBox_FXSymsAndStreams_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblAllSymsCount);
            this.groupBox1.Controls.Add(this.ListBox_AllSymsAndStreams);
            this.groupBox1.Location = new System.Drawing.Point(12, 146);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(156, 249);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "All Symbols on Chart";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Count:";
            // 
            // lblAllSymsCount
            // 
            this.lblAllSymsCount.AutoSize = true;
            this.lblAllSymsCount.Location = new System.Drawing.Point(59, 20);
            this.lblAllSymsCount.Name = "lblAllSymsCount";
            this.lblAllSymsCount.Size = new System.Drawing.Size(13, 13);
            this.lblAllSymsCount.TabIndex = 13;
            this.lblAllSymsCount.Text = "0";
            // 
            // ListBox_AllSymsAndStreams
            // 
            this.ListBox_AllSymsAndStreams.FormattingEnabled = true;
            this.ListBox_AllSymsAndStreams.Location = new System.Drawing.Point(12, 39);
            this.ListBox_AllSymsAndStreams.Name = "ListBox_AllSymsAndStreams";
            this.ListBox_AllSymsAndStreams.Size = new System.Drawing.Size(132, 199);
            this.ListBox_AllSymsAndStreams.TabIndex = 12;
            // 
            // ControlPanelForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(775, 662);
            this.Controls.Add(this.toolStripContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ControlPanelForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStripContainer1.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.BottomToolStripPanel.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ListBox ListBox_FXSymsAndStreams;
        private System.Windows.Forms.ListBox ListBoxFXCurrAndNames;
        private System.Windows.Forms.ListBox ListBox_AllSymsAndStreams;
        private System.Windows.Forms.ListBox ListBoxFPIRings;
        private System.Windows.Forms.Label lblFPIRings;
        private System.Windows.Forms.RadioButton radioClose;
        private System.Windows.Forms.RadioButton radioOpen;
        private System.Windows.Forms.Button btnCalcFPI;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblFXCurrCount;
        private System.Windows.Forms.Label lblFXSymsCount;
        private System.Windows.Forms.Label lblAllSymsCount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox checkBoxTop;
        private System.Windows.Forms.Label lblVer;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.ToolTip toolTipControlPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblEnabled;
    }
}