Welcome to Sharkscalper EA, that has multiple functions, including intellient grid , Martingale if needed, 
Multiple timer setting, Virtual Trades, Correlation technique, Trailing intelligently etc..

See the parameters
Use_limit_orders= If True then it places limit orders and if false places Stop orders.
Spread_Allow- Will not trade if spread is higher especially in news time.
Maximum_Trades_allowed_for_Pair= Restricts trades for pair.
Maximum_trades_greater than other pair= Is used in correlation strategy, whereby we can 
restrict a pair from placing more trades than the other pair. ( Magic number is taken into account )

Virtual_Orders= If true then no pending orders are placed in market. So that brokers won't
ban you.
Allow_delete_If Not Trigered= If true then the next below paramter of seconds is atken into account.

This strategy means ..that it will trade when there are sudden jumps in price.

TIMINGS
To enable timimgs you ahve to allow False>24h = True

Time format= 02:00-07:34;08:03-08:25;12:23-17:44;19:55-20:24

With the above EA, you can run multiple strategies.
For Unlimited version : contact ; seoshare@yahoo.com
