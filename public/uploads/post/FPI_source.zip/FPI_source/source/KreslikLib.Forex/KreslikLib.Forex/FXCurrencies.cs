﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace KreslikLib.Forex
{
    /// <summary>
    /// FX Currencies according to ISO 4217
    /// http://www.iso.org/iso/en/prods-services/popstds/currencycodeslist.html
    /// Last updated: Sep/11/2006
    /// </summary>
    public class FXCurrencies
    {
        private string[] CurrencyNames;
        private string[] AlphanumericCodes;
        private int[] NumericCodes;
        public int NumberOfCurrencies;

        public int IndexOfCurrencyName(string CurrencyName)
        {
            for (int i = 0; i < NumberOfCurrencies; i++)
            {
                if (CurrencyName == CurrencyNames[i])
                    return i;
            }
            return -1;
        }

        public int IndexOfAlphanumericCode(string AlphanumericCode)
        {
            for (int i = 0; i < NumberOfCurrencies; i++)
            {
                if (AlphanumericCode == AlphanumericCodes[i])
                    return i;
            }
            return -1;
        }

        public int IndexOfNumericCode(int NumericCode)
        {
            for (int i = 0; i < NumberOfCurrencies; i++)
            {
                if (NumericCode == NumericCodes[i])
                    return i;
            }
            return -1;
        }

        public string CurrencyName(int Index)
        {
            if (Index >= 0 && Index <= NumberOfCurrencies - 1)
                return CurrencyNames[Index];
            else
                return "";
        }

        public string AlphanumericCode(int Index)
        {
            if (Index >= 0 && Index <= NumberOfCurrencies - 1)
                return AlphanumericCodes[Index];
            else
                return "";
        }

        public int NumericCode(int Index)
        {
            if (Index >= 0 && Index <= NumberOfCurrencies - 1)
                return NumericCodes[Index];
            else
                return -1;
        }

        public FXCurrencies()
        {
            CurrencyNames = new string[]
            {
                "Lek", 
                "Algerian Dinar", 
                "Argentine Peso", 
                "Australian Dollar", 
                "Bahamian Dollar", 
                "Bahraini Dinar", 
                "Taka", 
                "Armenian Dram", 
                "Barbados Dollar", 
                "Bermudian Dollar", 
                "Ngultrum", 
                "Boliviano", 
                "Pula", 
                "Belize Dollar", 
                "Solomon Islands Dollar", 
                "Brunei Dollar", 
                "Kyat", 
                "Burundi Franc", 
                "Riel", 
                "Canadian Dollar", 
                "Cape Verde Escudo", 
                "Cayman Islands Dollar", 
                "Sri Lanka Rupee", 
                "Chilean Peso", 
                "Yuan Renminbi", 
                "Colombian Peso", 
                "Comoro Franc", 
                "Costa Rican Colon", 
                "Croatian Kuna", 
                "Cuban Peso", 
                "Cyprus Pound", 
                "Czech Koruna", 
                "Danish Krone", 
                "Dominican Peso", 
                "El Salvador Colon", 
                "Ethiopian Birr", 
                "Nakfa", 
                "Kroon", 
                "Falkland Islands Pound", 
                "Fiji Dollar", 
                "Djibouti Franc", 
                "Dalasi", 
                "Cedi", 
                "Gibraltar Pound", 
                "Quetzal", 
                "Guinea Franc", 
                "Guyana Dollar", 
                "Gourde", 
                "Lempira", 
                "Hong Kong Dollar", 
                "Forint", 
                "Iceland Krona", 
                "Indian Rupee", 
                "Rupiah", 
                "Iranian Rial", 
                "Iraqi Dinar", 
                "New Israeli Sheqel", 
                "Jamaican Dollar", 
                "Yen", 
                "Tenge", 
                "Jordanian Dinar", 
                "Kenyan Shilling", 
                "North Korean Won", 
                "Won", 
                "Kuwaiti Dinar", 
                "Som", 
                "Kip", 
                "Lebanese Pound", 
                "Loti", 
                "Latvian Lats", 
                "Liberian Dollar", 
                "Libyan Dinar", 
                "Lithuanian Litas", 
                "Pataca", 
                "Kwacha", 
                "Malaysian Ringgit", 
                "Rufiyaa", 
                "Maltese Lira", 
                "Ouguiya", 
                "Mauritius Rupee", 
                "Mexican Peso", 
                "Tugrik", 
                "Moldovan Leu", 
                "Moroccan Dirham", 
                "Rial Omani", 
                "Namibian Dollar", 
                "Nepalese Rupee", 
                "Netherlands Antillian Guilder", 
                "Aruban Guilder", 
                "Vatu", 
                "New Zealand Dollar", 
                "Cordoba Oro", 
                "Naira", 
                "Norwegian Krone", 
                "Pakistan Rupee", 
                "Balboa", 
                "Kina", 
                "Guarani", 
                "Nuevo Sol", 
                "Philippine Peso", 
                "Guinea-Bissau Peso", 
                "Qatari Rial", 
                "Old Leu", 
                "Russian Ruble", 
                "Rwanda Franc", 
                "Saint Helena Pound", 
                "Dobra", 
                "Saudi Riyal", 
                "Seychelles Rupee", 
                "Leone", 
                "Singapore Dollar", 
                "Slovak Koruna", 
                "Dong", 
                "Tolar", 
                "Somali Shilling", 
                "Rand", 
                "Zimbabwe Dollar", 
                "Sudanese Dinar", 
                "Lilangeni", 
                "Swedish Krona", 
                "Swiss Franc", 
                "Syrian Pound", 
                "Baht", 
                "Pa'anga", 
                "Trinidad and Tobago Dollar", 
                "UAE Dirham", 
                "Tunisian Dinar", 
                "Manat", 
                "Uganda Shilling", 
                "Denar", 
                "Egyptian Pound", 
                "Pound Sterling", 
                "Tanzanian Shilling", 
                "US Dollar", 
                "Peso Uruguayo", 
                "Uzbekistan Sum", 
                "Bolivar", 
                "Tala", 
                "Yemeni Rial", 
                "Serbian Dinar", 
                "Kwacha", 
                "New Taiwan Dollar", 
                "Metical", 
                "Azerbaijanian Manat", 
                "New Leu", 
                "WIR Euro", 
                "WIR Franc", 
                "New Turkish Lira", 
                "CFA Franc BEAC", 
                "East Caribbean Dollar", 
                "CFA Franc BCEAO", 
                "CFP Franc", 
                "SDR", 
                "Surinam Dollar", 
                "Malagascy Ariary", 
                "Unidad de Valor Real", 
                "Afghani", 
                "Somoni", 
                "Kwanza", 
                "Belarussian Ruble", 
                "Bulgarian Lev", 
                "Franc Congolais", 
                "Convertible Marks", 
                "Euro", 
                "Mexican Unidad de Inversion (UID)", 
                "Hryvnia", 
                "Lari", 
                "Mvdol", 
                "Zloty", 
                "Brazilian Real", 
                "Unidades de formento", 
                "US Dollar (Next day)", 
                "US Dollar (Same day)"
            };

            AlphanumericCodes = new string[]
            {
                "ALL", 
                "DZD", 
                "ARS", 
                "AUD", 
                "BSD", 
                "BHD", 
                "BDT", 
                "AMD", 
                "BBD", 
                "BMD", 
                "BTN", 
                "BOB", 
                "BWP", 
                "BZD", 
                "SBD", 
                "BND", 
                "MMK", 
                "BIF", 
                "KHR", 
                "CAD", 
                "CVE", 
                "KYD", 
                "LKR", 
                "CLP", 
                "CNY", 
                "COP", 
                "KMF", 
                "CRC", 
                "HRK", 
                "CUP", 
                "CYP", 
                "CZK", 
                "DKK", 
                "DOP", 
                "SVC", 
                "ETB", 
                "ERN", 
                "EEK", 
                "FKP", 
                "FJD", 
                "DJF", 
                "GMD", 
                "GHC", 
                "GIP", 
                "GTQ", 
                "GNF", 
                "GYD", 
                "HTG", 
                "HNL", 
                "HKD", 
                "HUF", 
                "ISK", 
                "INR", 
                "IDR", 
                "IRR", 
                "IQD", 
                "ILS", 
                "JMD", 
                "JPY", 
                "KZT", 
                "JOD", 
                "KES", 
                "KPW", 
                "KRW", 
                "KWD", 
                "KGS", 
                "LAK", 
                "LBP", 
                "LSL", 
                "LVL", 
                "LRD", 
                "LYD", 
                "LTL", 
                "MOP", 
                "MWK", 
                "MYR", 
                "MVR", 
                "MTL", 
                "MRO", 
                "MUR", 
                "MXN", 
                "MNT", 
                "MDL", 
                "MAD", 
                "OMR", 
                "NAD", 
                "NPR", 
                "ANG", 
                "AWG", 
                "VUV", 
                "NZD", 
                "NIO", 
                "NGN", 
                "NOK", 
                "PKR", 
                "PAB", 
                "PGK", 
                "PYG", 
                "PEN", 
                "PHP", 
                "GWP", 
                "QAR", 
                "ROL", 
                "RUB", 
                "RWF", 
                "SHP", 
                "STD", 
                "SAR", 
                "SCR", 
                "SLL", 
                "SGD", 
                "SKK", 
                "VND", 
                "SIT", 
                "SOS", 
                "ZAR", 
                "ZWD", 
                "SDD", 
                "SZL", 
                "SEK", 
                "CHF", 
                "SYP", 
                "THB", 
                "TOP", 
                "TTD", 
                "AED", 
                "TND", 
                "TMM", 
                "UGX", 
                "MKD", 
                "EGP", 
                "GBP", 
                "TZS", 
                "USD", 
                "UYU", 
                "UZS", 
                "VEB", 
                "WST", 
                "YER", 
                "CSD", 
                "ZMK", 
                "TWD", 
                "MZN", 
                "AZN", 
                "RON", 
                "CHE", 
                "CHW", 
                "TRY", 
                "XAF", 
                "XCD", 
                "XOF", 
                "XPF", 
                "XDR", 
                "SRD", 
                "MGA", 
                "COU", 
                "AFN", 
                "TJS", 
                "AOA", 
                "BYR", 
                "BGN", 
                "CDF", 
                "BAM", 
                "EUR", 
                "MXV", 
                "UAH", 
                "GEL", 
                "BOV", 
                "PLN", 
                "BRL", 
                "CLF", 
                "USN", 
                "USS"
            };

            NumericCodes = new int[]
            {
                8, 
                12, 
                32, 
                36, 
                44, 
                48, 
                50, 
                51, 
                52, 
                60, 
                64, 
                68, 
                72, 
                84, 
                90, 
                96, 
                104, 
                108, 
                116, 
                124, 
                132, 
                136, 
                144, 
                152, 
                156, 
                170, 
                174, 
                188, 
                191, 
                192, 
                196, 
                203, 
                208, 
                214, 
                222, 
                230, 
                232, 
                233, 
                238, 
                242, 
                262, 
                270, 
                288, 
                292, 
                320, 
                324, 
                328, 
                332, 
                340, 
                344, 
                348, 
                352, 
                356, 
                360, 
                364, 
                368, 
                376, 
                388, 
                392, 
                398, 
                400, 
                404, 
                408, 
                410, 
                414, 
                417, 
                418, 
                422, 
                426, 
                428, 
                430, 
                434, 
                440, 
                446, 
                454, 
                458, 
                462, 
                470, 
                478, 
                480, 
                484, 
                496, 
                498, 
                504, 
                512, 
                516, 
                524, 
                532, 
                533, 
                548, 
                554, 
                558, 
                566, 
                578, 
                586, 
                590, 
                598, 
                600, 
                604, 
                608, 
                624, 
                634, 
                642, 
                643, 
                646, 
                654, 
                678, 
                682, 
                690, 
                694, 
                702, 
                703, 
                704, 
                705, 
                706, 
                710, 
                716, 
                736, 
                748, 
                752, 
                756, 
                760, 
                764, 
                776, 
                780, 
                784, 
                788, 
                795, 
                800, 
                807, 
                818, 
                826, 
                834, 
                840, 
                858, 
                860, 
                862, 
                882, 
                886, 
                891, 
                894, 
                901, 
                943, 
                944, 
                946, 
                947, 
                948, 
                949, 
                950, 
                951, 
                952, 
                953, 
                960, 
                968, 
                969, 
                970, 
                971, 
                972, 
                973, 
                974, 
                975, 
                976, 
                977, 
                978, 
                979, 
                980, 
                981, 
                984, 
                985, 
                986, 
                990, 
                997, 
                998
            };

            NumberOfCurrencies = CurrencyNames.Length;
        }

    }

    public static class KToolsFX
    {
        public static bool SymbolIsFXSymbol(string Symbol)
        {
            if (!((Symbol.Length == 6) || ((Symbol.Length == 7) && (Symbol[3] == '/'))))
            {
                return false;
            }
            else
            {
                bool FirstPartIsCurrency = false;
                bool SecondPartIsCurrency = false;
                FXCurrencies FX = new FXCurrencies();

                for (int i = 0; i < FX.NumberOfCurrencies; i++)
                {
                    if (FX.AlphanumericCode(i) == FirstCurrencyInFXSymbol(Symbol))
                        FirstPartIsCurrency = true;
                    if (FX.AlphanumericCode(i) == SecondCurrencyInFXSymbol(Symbol))
                        SecondPartIsCurrency = true;

                    if (FirstPartIsCurrency && SecondPartIsCurrency)
                        return true;
                }

                return false;
            }
        }

        /// <summary>
        /// Extracts alphabetically sorted list of unique currencies.
        /// </summary>
        /// <param name="FXSymbols">Input FX symbols.</param>
        /// <returns>Returns string[] of unique currencies.</returns>
        public static string[] ExtractUniqueCurrenciesFromFXSymbols(string[] FXSymbols)
        {
            ArrayList TempCurrenciesArray = new ArrayList();
            string[] ReturnCurrenciesArray;

            string FirstCurrency;
            string SecondCurrency;
            bool FirstCurrencyIsNew;
            bool SecondCurrencyIsNew;

            for (int i = 0; i < FXSymbols.Length; i++)
            {
                FirstCurrency = FirstCurrencyInFXSymbol(FXSymbols[i]);
                SecondCurrency = SecondCurrencyInFXSymbol(FXSymbols[i]);

                FirstCurrencyIsNew = true;
                SecondCurrencyIsNew = true;

                foreach (string CurrencyInList in TempCurrenciesArray)
                {
                    if (CurrencyInList == FirstCurrency) FirstCurrencyIsNew = false;
                    if (CurrencyInList == SecondCurrency) SecondCurrencyIsNew = false;
                }

                if (FirstCurrencyIsNew) TempCurrenciesArray.Add(FirstCurrency);
                if (SecondCurrencyIsNew) TempCurrenciesArray.Add(SecondCurrency);

            }

            TempCurrenciesArray.Sort();

            ReturnCurrenciesArray = new string[TempCurrenciesArray.Count];

            for (int i = 0; i < TempCurrenciesArray.Count; i++)
            {
                ReturnCurrenciesArray[i] = TempCurrenciesArray[i].ToString();
            }
            return ReturnCurrenciesArray;
        }

        public static string FirstCurrencyInFXSymbol(string ForexSymbol)
        {
            return ForexSymbol.Substring(0, 3);
        }

        public static string SecondCurrencyInFXSymbol(string ForexSymbol)
        {
            switch (ForexSymbol.Length)
            {
                case 6:
                default:
                    return ForexSymbol.Substring(3, 3);
                case 7:
                    return ForexSymbol.Substring(4, 3);
            }
        }

        /// <summary>
        /// Converts 6 chars FX symbol (EURUSD) to 7 chars (EUR/USD).
        /// If the input is 7 chars, no modification is made.
        /// </summary>
        /// <param name="FXSymbol"></param>
        public static string ConvertFXSym6to7(string FXSymbol)
        {
            if (FXSymbol.Length == 7)
            {
                return FXSymbol;
            }
            else if (FXSymbol.Length == 6)
            {
                return FirstCurrencyInFXSymbol(FXSymbol) + "/" + SecondCurrencyInFXSymbol(FXSymbol);
            }
            else
            {
                return "";
            }
        }

        /// <summary>
        /// Returns true if the two FX symbols have at least one currency in common.
        /// Also returns bool Reversed:
        /// false if (Curr1 in Sym1 == Curr1 in Sym1) || (Curr2 in Sym1 == Curr2 in Sym2). Example (EUR): EUR/USD, EUR/JPY
        /// true if (Curr1 in Sym1 == Curr2 in Sym2) || (Curr2 in Sym1 == Curr1 in Sym2). Example (USD): GBP/USD, USD/JPY
        /// </summary>
        public static bool AtLeastOneCurrMatches(string FXSymbol1, string FXSymbol2, out bool Reversed)
        {
            string Sym1Curr1 = KToolsFX.FirstCurrencyInFXSymbol(FXSymbol1);
            string Sym1Curr2 = KToolsFX.SecondCurrencyInFXSymbol(FXSymbol1);
            string Sym2Curr1 = KToolsFX.FirstCurrencyInFXSymbol(FXSymbol2);
            string Sym2Curr2 = KToolsFX.SecondCurrencyInFXSymbol(FXSymbol2);

            if (Sym1Curr1 == Sym2Curr1 || Sym1Curr2 == Sym2Curr2)
            {
                Reversed = false;
                return true;
            }
            else if (Sym1Curr1 == Sym2Curr2 || Sym1Curr2 == Sym2Curr1)
            {
                Reversed = true;
                return true;
            }
            else
                Reversed = false;
                return false;
        }

        /// <summary>
        /// Reverses currencies in FX symbol.
        /// Example: EUR/USD > USD/EUR
        /// </summary>
        /// <param name="FXSymbol"></param>
        /// <returns></returns>
        public static string ReverseCurrenciesInFXSymbol(string FXSymbol)
        {
            string Currency1 = SecondCurrencyInFXSymbol(FXSymbol);
            string Currency2 = FirstCurrencyInFXSymbol(FXSymbol);

            return Currency1 + @"/" + Currency2;
        }
    }
}
