﻿using System;
using System.Collections.Generic;
using System.Text;

using KreslikLib.Common;
using KreslikLib.Forex;
using KreslikLib.Neo;
using NeoTicker;
using NeoFPI.Properties;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace NeoFPI
{
    public delegate void InvokeDelegate();

    class FPIToolsClass
    {
        CommonObject C;

        public FPIToolsClass(CommonObject C)
        {
            this.C = C;
        }

        internal void SetPlots()
        {
            if (C.FPIObject.FPIRingSelected > -1)
            {
                double ValueToPlot = 1;
                double ThisBarPrice = 0;
                for (int fxSymID = 0; fxSymID < C.FPIObject.FXSymsCount; fxSymID++)
                {
                    switch (C.AppSettings.Price)
                    {
                        case BarPrice.Open:
                            ThisBarPrice = C.N.DataSeries().get_Items(C.FPIObject.FXUniqueStreams[fxSymID]).get_Open(0);
                            break;
                        case BarPrice.Close:
                            ThisBarPrice = C.N.DataSeries().get_Items(C.FPIObject.FXUniqueStreams[fxSymID]).get_Close(0);
                            break;
                    }
                    switch (C.FPIObject.FPIRingToPlot[fxSymID])
                    {
                        case SymbolInRing.UsedNorm:
                            ValueToPlot *= ThisBarPrice;
                            break;
                        case SymbolInRing.UsedReversed:
                            ValueToPlot *= (1 / ThisBarPrice);
                            break;
                    }
                }
            C.N.ItSelf().set_Plot(1, ValueToPlot);
            }
        }

        internal void PassTheNeoReference(NTIndicatorObjects N)
        {
            this.C.N = N;
        }

        internal void RefreshServices()
        {
            C.AppSettings.Reload();

            if (C.PleaseWait == null && C.ControlPanel == null)
            {
                C.PleaseWait = new PleaseWaitForm(C);
                C.PleaseWait.Show();
                Application.DoEvents();
            }

            if (C.ControlPanel == null)
            {
                C.ControlPanel = new ControlPanelForm(C);
            }
        }

    }
}
