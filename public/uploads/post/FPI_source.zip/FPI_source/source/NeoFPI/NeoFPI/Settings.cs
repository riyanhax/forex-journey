namespace NeoFPI.Properties
{
    // This class allows you to handle specific events on the settings class:

    //  The SettingsLoaded event is raised after the setting values are loaded.
    //  The SettingChanging event is raised before a setting's value is changed.
    //  The PropertyChanged event is raised after a setting's value is changed.
    //  The SettingsSaving event is raised before the setting values are saved.
    internal sealed partial class Settings
    {

        public Settings()
        {
            // // To add event handlers for saving and changing settings, uncomment the lines below:
            //this.SettingsLoaded += this.SettingsLoadedEventHandler;
            ////
            //this.SettingChanging += this.SettingChangingEventHandler;

            //this.SettingsSaving += this.SettingsSavingEventHandler;
            //
            this.PropertyChanged += this.PropertyChangedEventHandler;
        }

        private void SettingsLoadedEventHandler(object sender, System.Configuration.SettingsLoadedEventArgs e)
        {
            KreslikLib.Common.KTools.DebugMsg("Settings loaded");
        }

        private void SettingChangingEventHandler(object sender, System.Configuration.SettingChangingEventArgs e)
        {
            KreslikLib.Common.KTools.DebugMsg("Settings changing");
        }

        private void SettingsSavingEventHandler(object sender, System.ComponentModel.CancelEventArgs e)
        {
            KreslikLib.Common.KTools.DebugMsg("Settings saving");
        }

        private void PropertyChangedEventHandler(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            //KreslikLib.Common.KTools.DebugMsg("Property changed");
            this.Save();
        }
        
    }
}
