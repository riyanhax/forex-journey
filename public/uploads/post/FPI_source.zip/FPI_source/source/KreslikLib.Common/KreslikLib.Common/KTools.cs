﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace KreslikLib.Common
{
    /// <summary>
    /// Enumeration for PortionFromCharSeparatedLine method.
    /// </summary>
    public enum StartFrom
    {
        Begin,
        End
    }

    public static class KTools
    {
        /// <summary>
        /// Compares two string arrays by going thru all elements one by one.
        /// </summary>
        /// <param name="FirstArray">First string array.</param>
        /// <param name="SecondArray">Second string array.</param>
        /// <returns></returns>
        public static bool StringArraysAreEqual(string[] FirstArray, string[] SecondArray)
        {
            // let's get rid of the null Arrays
            if ((FirstArray == null && SecondArray != null) ||
                (FirstArray != null && SecondArray == null))
            {
                return false;
            }
            else if (FirstArray == null && SecondArray == null)
            {
                return true;
            } // after this, we know that both Arrays are not-null, so we can access their .GetType and .Length properties
            else if (FirstArray.Length != SecondArray.Length)
            {
                return false;
            }
            else if (FirstArray.Length == 0 && SecondArray.Length == 0) // a shortcut to return true if .Lengths == 0
            {
                return true;
            }
            else // now it's clear both arrays != null, their .Lengths > 0 && are the same .Length
            {
                for (int i = 0; i < FirstArray.Length; i++) // we could as well use SecondArray.Length
                {
                    if (FirstArray[i] != SecondArray[i])
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// Shows a message box with the specified message if DEBUG element exists.
        /// </summary>
        /// <param name="StringToShow">String to show in a message box.</param>
        /// <returns></returns>
        public static void DebugMsg(string StringToShow)
        {
            bool DEBUG = false;

            DEBUG = (File.Exists(@"c:\debug.yes"));

            if (DEBUG)
            {
                InfoBox(StringToShow, "Debugging Window");
            }
        }

        /// <summary>
        /// Returns portion from the special character (like comma) separated line.
        /// </summary>
        /// <param name="CharSepLine">Special char-separated input line.</param>
        /// <param name="PortionIndex">The index of the portion to get, starting from 0.</param>
        /// <param name="CountFrom">Which side of the string to count the index from.</param>
        /// <param name="SeparationChar">SeparationChar, like ',' (comma).</param>
        /// <returns></returns>
        public static string PortionFromCharSeparatedLine(string CharSepLine, int PortionIndex, StartFrom CountFrom, char SeparationChar)
        {
            if (CharSepLine == null)
            {
                return null;
            }
            else
            {
                string Portion = "";
                int CurrentIndex = 0;

                switch (CountFrom)
                {
                    case StartFrom.Begin:
                        for (int i = 0; i < CharSepLine.Length; i++)
                        {
                            if (CharSepLine[i] == SeparationChar)
                            {
                                CurrentIndex++;
                            }
                            else if (CurrentIndex == PortionIndex)
                            {
                                Portion += CharSepLine[i];
                            }
                        }
                        break;
                    case StartFrom.End:
                        for (int i = CharSepLine.Length - 1; i > -1; i--)
                        {
                            if (CharSepLine[i] == SeparationChar)
                            {
                                CurrentIndex++;
                            }
                            else if (CurrentIndex == PortionIndex)
                            {
                                Portion += CharSepLine[i];
                            }
                        }
                        Portion = ReverseString(Portion);
                        break;
                }

                return Portion;
            }
        }

        /// <summary>
        /// Return a portion from comma-separated file.
        /// </summary>
        /// <param name="CSVLine"></param>
        /// <param name="PortionIndex"></param>
        /// <param name="CountFrom"></param>
        /// <returns></returns>
        public static string PortionFromCSVLine(string CSVLine, int PortionIndex, StartFrom CountFrom)
        {
            return PortionFromCharSeparatedLine(CSVLine, PortionIndex, CountFrom, ',');
        }

        /// <summary>
        /// Reverses the order of characters in a string.
        /// </summary>
        /// <param name="InputString">The input string.</param>
        /// <returns></returns>
        public static string ReverseString(string InputString)
        {
            if (InputString == null)
            {
                return null;
            }
            else if (InputString.Length < 2) // no reversing necessary for strings with length 0 or 1
            {
                return InputString;
            }
            else
            {
                string ReversedString = "";
                for (int i = InputString.Length - 1; i > -1; i--)
                {
                    ReversedString += InputString[i];
                }

                return ReversedString;
            }
        }

        /// <summary>
        /// Converts Microsoft DateTime format to YYYYMMDD.
        /// </summary>
        /// <param name="DateTimeValue">Input DateTime value.</param>
        /// <returns></returns>
        public static string DateTimeToYYYYMMDD(DateTime DateTimeValue)
        {
            string ReturnString = "";
            ReturnString = DateTimeValue.Year.ToString();

            if (DateTimeValue.Month < 10) ReturnString += "0";
            ReturnString += DateTimeValue.Month.ToString();

            if (DateTimeValue.Day < 10) ReturnString += "0";
            ReturnString += DateTimeValue.Day.ToString();

            return ReturnString;
        }

        /// <summary>
        /// Shows InfoBox with specified Text and Caption.
        /// </summary>
        /// <param name="Text">Text to show.</param>
        /// <param name="Caption">Caption to show.</param>
        public static void InfoBox(string Text, string Caption)
        {
            MessageBox.Show(Text, Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Shows InfoBox with specified TextArray (one item per line) and Caption.
        /// </summary>
        /// <param name="TextArray">Text Array to show.</param>
        /// <param name="Caption">Caption to show.</param>
        public static void InfoBox(string[] TextArray, string Caption)
        {
            InfoBox(ConvertStrArrayToStr(TextArray), Caption);
        }

        /// <summary>
        /// Converts string array to string.
        /// </summary>
        /// <param name="StringArray"></param>
        /// <returns></returns>
        public static string ConvertStrArrayToStr(string[] StringArray)
        {
            string OutputString = "";
            foreach (string StringItem in StringArray)
            {
                OutputString += StringItem + "\n";
            }

            return OutputString;
        }

        /// <summary>
        /// Shows InfoBox with specified IntArray (one item per line) and Caption.
        /// </summary>
        /// <param name="IntArray">Int array to show.</param>
        /// <param name="Caption">Caption to show.</param>
        public static void InfoBox(int[] IntArray, string Caption)
        {
            string OutputString = "";
            foreach (int IntItem in IntArray)
            {
                OutputString += IntItem.ToString() + "\n";
            }

            InfoBox(OutputString, Caption);
        }

        /// <summary>
        /// Mathematical Power. Returns Unsigned Long Int.
        /// </summary>
        /// <param name="InputNumber"></param>
        /// <param name="Exponent"></param>
        /// <returns></returns>
        public static ulong Power(int InputNumber, int Exponent)
        {
            ulong Result = 1;

            for (int i = 0; i < Exponent; i++)  
            {
                Result = (ulong)InputNumber * Result;
            }

            return Result;
        }

        /// <summary>
        /// Concatenates arrays' contents one element by one to a new string array.
        /// Puts a Separator string between the original elements.
        /// Returns bool if the strings have changed.
        /// </summary>
        /// <param name="OutputArray">Output array to store the concatenated arrays to.</param>
        public static void ConcatenateArrays<T1,T2,T3>(ref string[] OutputArray, out bool ArraysHaveChanged, T1[] Array1, string Separator1, T2[] Array2, string Separator2, T3[]Array3)
        {
            string[] ReturnArray;
            if (Array1.Length == Array2.Length && Array2.Length == Array3.Length)
            {
                ReturnArray = new string[Array1.Length];

                for (int i = 0; i < Array1.Length; i++)
                {
                    ReturnArray[i] = Array1[i].ToString() + Separator1 + Array2[i].ToString() + Separator2 + Array3[i].ToString();
                }

                if (StringArraysAreEqual(ReturnArray, OutputArray))
                    ArraysHaveChanged =  false; // the arrays have NOT changed = false
                else
                {
                    OutputArray = ReturnArray;
                    ArraysHaveChanged = true; // the arrays have changed
                }
            }
            else
                // if the input arrays are not the same length, we assume the concatenated arrays are not same
                ArraysHaveChanged = true;
        }

        /// <summary>
        /// 2 input arrays overload.
        /// </summary>
        public static void ConcatenateArrays<T1, T2>(ref string[] OutputArray, out bool ArraysHaveChanged, T1[] Array1, string Separator1, T2[] Array2)
        {
            string Separator2 = "";
            string[] Array3 = new string[Array2.Length];
            for (int i = 0; i < Array3.Length; i++)
            {
                Array3[i] = "";
            }

            ConcatenateArrays(ref OutputArray, out ArraysHaveChanged, Array1, Separator1, Array2, Separator2, Array3);
        }

        /// <summary>
        /// Initializes all array elements with a given startup value.
        /// </summary>
        /// <typeparam name="T1">Data type of the array.</typeparam>
        /// <param name="ArraySize">Number of array elements.</param>
        /// <param name="ValueToInitializeWith">Initial value of every array element.</param>
        /// <returns></returns>
        public static T1[] InitializeArray<T1>(int ArraySize, T1 ValueToInitializeWith)
        {
            T1[] OutputArray = new T1[ArraySize];

            for (int i = 0; i < OutputArray.Length; i++)
            {
                OutputArray[i] = ValueToInitializeWith;
            }

            return OutputArray;
        }

        /// <summary>
        /// Converts input ArrayList to output Array[].
        /// </summary>
        public static void ConvertArrayListToArray<T1>(ArrayList InputArayList, out T1[] OutputArray)
        {
            OutputArray = new T1[InputArayList.Count];
            InputArayList.CopyTo(OutputArray);
        }
    }
}