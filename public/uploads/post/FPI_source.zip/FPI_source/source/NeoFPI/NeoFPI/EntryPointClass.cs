﻿using NeoTicker;

namespace NeoFPI
{
    [System.Security.SuppressUnmanagedCodeSecurityAttribute]
    public class EntryPointClass: IDLIndicator
    {
        CommonObject C;

        public EntryPointClass()
        {
            C = new CommonObject();
        }

        public double IDLCallEx(NTIndicatorObjects N)
        {
            C.NeoEvents.CheckForEvents(N);

            return 0;
        }
    }
}