﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
//
using NeoTicker;
using NeoFPI.Properties;
using KreslikLib.Common;
using KreslikLib.Neo;
using KreslikLib.Forex;
using System.Drawing;

namespace NeoFPI
{
    public partial class ControlPanelForm : Form
    {
        CommonObject C;
        bool LayoutDone = false;
        const string ControlPanelTitle = "[KreslikNeoTools] NeoFPI Control Panel";
        const string NoFPIRings = "No FPI Rings available.";

        public ControlPanelForm(CommonObject C)
        {
            InitializeComponent();

            this.C = C;
            RefreshControlPanel();
            
            C.NeoEvents.FirstCalledEvent += new FirstCalledHandler(RefreshControlPanel);
            C.NeoEvents.SymbolsChangedEvent += new SymbolsChangedHandler(KToolsNeo.RefreshChart);
            C.NeoEvents.RemoveCalledTimerEvent += new RemoveCalledHandler(RemoveCalledEvent);

            this.SuspendLayout();
            this.Text = ControlPanelTitle;
            this.lblFPIRings.Text = NoFPIRings;
            this.lblVer.Text = C.AppSettings.Version;
            this.InitializeRadioButtons(C.AppSettings.Price);
            this.ResumeLayout(false);
            this.PerformLayout();

            if (C.PleaseWait.Visible)
            {
                this.TopMost = false;
                SetTopMostVisualOnly();
                this.Show();
                Application.DoEvents();
                ThreadStart DisposePleaseWait = new ThreadStart(DisposePleaseWaitWindow);
                Thread DisposePleaseWaitThread = new Thread(DisposePleaseWait);
                DisposePleaseWaitThread.Start();
            }
            else
            {
                this.SetTopMost();
                this.Show();
                Application.DoEvents();
            }
        }

        internal void RemoveCalledEvent()
        {
            InvokeDelegate ThreadSafe = new InvokeDelegate(InvokeRemove);
            this.Invoke(ThreadSafe);
        }
        private void InvokeRemove()
        {
            this.lblEnabled.Text = "NO";
            this.lblEnabled.BackColor = Color.Red;

            IndicatorDisabledVisuals();
        }

        private void DisposePleaseWaitWindow()
        {
            Thread.Sleep(2000);
            InvokeDelegate SetTopMostD = new InvokeDelegate(SetTopMost);
            this.Invoke(SetTopMostD);
            C.PleaseWait.CloseWaitForm();
        }

        internal void SetTopMost()
        {
            this.TopMost = this.checkBoxTop.Checked = C.AppSettings.TopMost;
        }

        internal void SetTopMostVisualOnly()
        {
            this.checkBoxTop.Checked = C.AppSettings.TopMost;
        }

        private void checkBoxTop_CheckedChanged(object sender, EventArgs e)
        {
            C.AppSettings.TopMost = this.checkBoxTop.Checked;
            SetTopMost();
        }

        void RefreshControlPanel()
        {
            IndicatorEnabledVisuals();

            bool AllSymStrmChanged, FXSymStrmChanged, FXCurrChanged;
            C.FPIObject.Initialize(out AllSymStrmChanged, out FXSymStrmChanged, out FXCurrChanged);

            this.SuspendLayout();

            if (AllSymStrmChanged)
            {
                this.lblAllSymsCount.Text = C.FPIObject.AllSymbolsOnChart.Length.ToString();
                this.ListBox_AllSymsAndStreams.Items.Clear();
                this.ListBox_AllSymsAndStreams.Items.AddRange(C.FPIObject.AllSymbolsAndStreams);
            }

            if (FXSymStrmChanged)
            {
                this.lblFXSymsCount.Text = C.FPIObject.FXSymsCount.ToString();
                this.ListBox_FXSymsAndStreams.Items.Clear();
                this.ListBox_FXSymsAndStreams.Items.AddRange(C.FPIObject.FXSymsAndStreams);
                ClearFPIListBox();
                this.lblFPIRings.Text = NoFPIRings;
            }

            if (FXCurrChanged)
            {
                this.lblFXCurrCount.Text = C.FPIObject.FXCurrAndNames.Length.ToString();
                this.ListBoxFXCurrAndNames.Items.Clear();
                this.ListBoxFXCurrAndNames.Items.AddRange(C.FPIObject.FXCurrAndNames);
            }

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private void IndicatorEnabledVisuals()
        {
            this.lblEnabled.Text = "Yes";
            this.lblEnabled.BackColor = SystemColors.Control;
            this.btnCalcFPI.Enabled = true;
        }

        private void IndicatorDisabledVisuals()
        {
            C.FPIObject.ResetSymbolsAndCurrencies();
            this.btnCalcFPI.Enabled = false;
            this.lblAllSymsCount.Text = "0";
            this.lblFXSymsCount.Text = "0";
            this.lblFXCurrCount.Text = "0";
            this.ListBox_AllSymsAndStreams.Items.Clear();
            this.ListBox_FXSymsAndStreams.Items.Clear();
            this.ListBoxFXCurrAndNames.Items.Clear();
            this.ClearFPIListBox();
        }

        private void ClearFPIListBox()
        {
            this.ListBoxFPIRings.Items.Clear();
            RadioButtonsEnabled = false;
            C.FPIObject.FPIRingSelected = -1;
            this.lblFPIRings.Text = this.statusLabel.Text = NoFPIRings;
        }

        private void InitializeRadioButtons(BarPrice Price)
        {
            LayoutDone = false;
            switch (Price)
            {
                case BarPrice.Close:
                    this.radioClose.Checked = true;
                    break;
                case BarPrice.Open:
                    this.radioOpen.Checked = true;
                    break;
            }
            LayoutDone = true;
        }

        private void ListBoxFPIRings_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.ListBoxFPIRings.SelectedIndex != C.FPIObject.FPIRingSelected)
            {
                C.FPIObject.SetFPIRingToPlot(this.ListBoxFPIRings.SelectedIndex);
                RadioButtonsEnabled = true;
                KToolsNeo.RefreshChart();
            }
        }

        private void RadioButtonsCheckChanged(object sender, EventArgs e)
        {
            if (LayoutDone)
            {
                if (this.radioOpen.Checked) C.AppSettings.Price = BarPrice.Open;
                if (this.radioClose.Checked) C.AppSettings.Price = BarPrice.Close;

                KToolsNeo.RefreshChart();
            }
        }

        private void CalculateRings_click(object sender, EventArgs e)
        {
            if (C.FPIObject.FXSymsCount < 3)
                KTools.InfoBox("At least 3 unique FX symbols required for FPI rings calculation.", "Not enough unique FX symbols");
            else
            {

                this.lblFPIRings.Text = this.statusLabel.Text = "Calculating rings...";

                ClearFPIListBox();

                CalcRingsForm CalcForm = new CalcRingsForm(C);
                DialogResult Result = CalcForm.ShowDialog();

                if (C.FPIObject.FPIRingsSymbols != null && C.FPIObject.FPIRingsSymbols.Length > 0 && Result == DialogResult.OK)
                {
                    this.ListBoxFPIRings.Items.AddRange(C.FPIObject.FPIRingsSymbols);
                    this.lblFPIRings.Text = this.statusLabel.Text = C.FPIObject.FPIRingsSymbols.Length.ToString() + " FPI rings found.";
                }
                else if (Result == DialogResult.Cancel)
                {
                    this.lblFPIRings.Text = this.statusLabel.Text = "FPI rings calculation aborted.";
                }
                else
                {
                    this.lblFPIRings.Text = this.statusLabel.Text = "No FPI rings found.";
                }
            }
        }

        private bool RadioButtonsEnabled
        {
            set
            {
                this.radioOpen.Enabled = value;
                this.radioClose.Enabled = value;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (C != null && C.ControlPanel != null) // not checking for this sometimes causes strange errors in Neo
            {
                C.ControlPanel = null;
                C.PleaseWait = null;
            }

            C.FPIObject.AllSymbolsAndStreams = null;
            C.FPIObject.FXSymsAndStreams = null;
            C.FPIObject.FXCurrAndNames = null;

            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                Process.Start(C.AppSettings.WebBrowser, C.AppSettings.FPI_Url);
            }
            catch (Exception MyEx)
            {
                MessageBox.Show(MyEx.Message, "Error");
            }
        }

        private void ListBox_FXSymsAndStreams_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (C.FPIObject.FXSymsCount > 0)
            {
                FXCurrencies FX = new FXCurrencies();
                KTools.InfoBox(FX.CurrencyName(FX.IndexOfAlphanumericCode(KToolsFX.FirstCurrencyInFXSymbol(C.FPIObject.FXUniqueSyms[ListBox_FXSymsAndStreams.SelectedIndex]))) + @" / " + FX.CurrencyName(FX.IndexOfAlphanumericCode(KToolsFX.SecondCurrencyInFXSymbol(C.FPIObject.FXUniqueSyms[ListBox_FXSymsAndStreams.SelectedIndex]))) + "\nData stream: " + C.FPIObject.FXUniqueStreams[ListBox_FXSymsAndStreams.SelectedIndex], C.FPIObject.FXUniqueSyms[ListBox_FXSymsAndStreams.SelectedIndex]);
            }
        }
    }
}