
Title: Hunter_v9d  	Currency Pair: EUR/USD      

Timeframe: M5		Lots Size: Auto
			
Compatibility:	Only MT4

Note: Put kernl320.dll file on libraries folder.

