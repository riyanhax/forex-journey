using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using NeoTicker;
using System.Collections;
using KreslikLib.Common;
using KreslikLib.Neo;
using System.Threading;

namespace KreslikLib.Neo
{
    public delegate void FirstCalledWithObjectHandler(NTIndicatorObjects N);
    public delegate void FirstCalledHandler();
    public delegate void SymbolsChangedHandler();
    public delegate void IDLCalledHandler();
    public delegate void RemoveCalledHandler();
    public delegate void HostWindowNameChanged();
    public delegate void FuncNameChanged();
    
    public class NeoEventsClass : IDisposable
    {
        NTIndicatorObjects N;
        const int DefaultTimerSleepMilliseconds = 500;
        int TimerSleep;
        Thread TimerThread;

        public NeoEventsClass()
        {
            this.TimerSleep = DefaultTimerSleepMilliseconds;
        }
        // we may instantiate the NeoEvents object with the following constructor and change the default timer poll interval:
        public NeoEventsClass(int TimerSleep)
        {
            this.TimerSleep = TimerSleep;
        }

        public void CheckForEvents(NTIndicatorObjects N)
        {
            // put all the various event checking methods here
            CheckIfFirstCalled(N);
            CheckIfIDLCalled();
            if (!TimerRunning) CheckForTimerEvents();
            if (N.Data1().IsLastBar) CheckIfSymbolsChanged();
        }

        private bool TimerRunning = false;
        private void CheckForTimerEvents()
        {
            StartTimer();
            TimerRunning = true;
        }

        private void StartTimer()
        {
            ThreadStart StartTimerDelegate = new ThreadStart(TimerJob);
            TimerThread = new Thread(StartTimerDelegate);
            TimerThread.Start();
        }

        #region Timer Thread code
        private void TimerJob()
        {
            for (; ; )
            {
                TimerEvents();
                Thread.Sleep(TimerSleep);
            }
        }

        /// <summary>
        /// WARNING! This event runs on a separate thread, so you have to use delegate, invoke etc. to handle it.
        /// </summary>
        public event RemoveCalledHandler RemoveCalledTimerEvent;
        private volatile bool RemoveCalled = false;

        public event HostWindowNameChanged HostWindowNameChangedTimerEvent;
        private string HostWindowName = "NULL";

        public event FuncNameChanged FuncNameChangedTimerEvent;
        private string FuncName = "";

        private void TimerEvents()
        {
            // Function name changed event:
            if (FuncNameChangedTimerEvent != null && N.ItSelf().FuncName.ToString() != FuncName)
            {
                FuncName = N.ItSelf().FuncName.ToString();
                FuncNameChangedTimerEvent();
            }

            // RemoveCall timer event:
            if (!RemoveCalled && N.ItSelf().RemoveCall && RemoveCalledTimerEvent != null)
            {
                RemoveCalled = true;
                RemoveCalledTimerEvent();
            }

            // Host window name changed timer event.
            // When the chart is closed, N.ItSelf().Host is throwing an excpetion!!
            // See http://kreslik.com/forums/viewtopic.php?t=289
            if (HostWindowNameChangedTimerEvent != null && FuncName != "Unknown")
            {
                string NewHostWindowName = "";
                if (N.ItSelf().Host != null && N.ItSelf().FuncName.ToString() != "Unknown")
                {
                    NewHostWindowName = N.ItSelf().Host.ToString();
                }
                else
                {
                    NewHostWindowName = "NULL";
                }
                if (NewHostWindowName != HostWindowName)
                {
                    HostWindowName = NewHostWindowName;
                    HostWindowNameChangedTimerEvent();
                }
            }
        }
        #endregion Timer Thread code

        /// <summary>
        /// Called every time the IDL indicator is called.
        /// </summary>
        public event IDLCalledHandler IDLCalledEvent;
        private void CheckIfIDLCalled()
        {
            if (IDLCalledEvent != null)
            {
                IDLCalledEvent();
            }
        }

        public event FirstCalledWithObjectHandler FirstCalledWithObjectEvent;
        public event FirstCalledHandler FirstCalledEvent;
        private void CheckIfFirstCalled(NTIndicatorObjects N)
        {
            if (N.ItSelf().FirstCall)
            {
                this.N = N;
                // the object-pass version must come first since the non-object-pass version might be using the N object internally
                if (FirstCalledWithObjectEvent != null) FirstCalledWithObjectEvent(N);
                if (FirstCalledEvent != null) FirstCalledEvent();
                ResetStatesAtFirstCall();
            }
        }

        private void ResetStatesAtFirstCall()
        {
            // put all the state resetting statements here
            RemoveCalled = false;
        }

        string[] PreviousSymbolsOnChart = null;
        public event SymbolsChangedHandler SymbolsChangedEvent;
        private void CheckIfSymbolsChanged()
        {
            string[] CurrentSymbolsOnChart = KToolsNeo.ExtractAllSymbolsFromChart(N);

            if (!KTools.StringArraysAreEqual(CurrentSymbolsOnChart, PreviousSymbolsOnChart))
            {
                // avoid firing off SymbolsChangedEvent when indicator is first applied on chart 
                if (PreviousSymbolsOnChart != null && SymbolsChangedEvent != null)
                {
                    SymbolsChangedEvent();
                }
                PreviousSymbolsOnChart = new string[CurrentSymbolsOnChart.Length];
                CurrentSymbolsOnChart.CopyTo(PreviousSymbolsOnChart, 0);
            }
        }

        /// <summary>
        /// We should dispose of the NeoEvents object and stop the timer events firing.
        /// </summary>
        public void Dispose()
        {
            TimerThread.Abort();
            TimerThread.Join();
        }
    }
}