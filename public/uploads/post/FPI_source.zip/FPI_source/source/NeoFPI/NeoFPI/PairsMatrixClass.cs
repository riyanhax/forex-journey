﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using NeoTicker;
using System.Collections;
using KreslikLib.Common;
using KreslikLib.Neo;
using KreslikLib.Forex;

namespace NeoFPI
{
    public class PairsMatrixClass
    {
        CommonObject C;
        bool[,] PairsMatrix;
        internal string LastCombinationBinary;

        /// <summary>
        /// Initializes the matrix to reflect that a new set of FX Symbols is on the chart.
        /// </summary>
        /// <param name="FXUniqueSyms"></param>
        /// <param name="FXUniqueCurrencies"></param>
        internal void Initialize(CommonObject C)
        {
            this.C = C;
            int size = C.FPIObject.FXUniqueCurrCount;
            PairsMatrix = new bool[size, size]; //[x, y]
        }

        private void ResetMatrix()
        {
            for (int x = 0; x < C.FPIObject.FXUniqueCurrCount; x++)
            {
                for (int y = 0; y < C.FPIObject.FXUniqueCurrCount; y++)
                {
                    PairsMatrix[x, y] = false;
                }
            }
        }

        internal bool TryCombination(ulong NumericalOrder)
        {
            ResetMatrix(); // sets all pairs in a matrix to false

            LastCombinationBinary = DecimalToStringBin(NumericalOrder, C.FPIObject.FXSymsCount);

            SetUsedPairs(LastCombinationBinary);

            int row = 0;
            bool RowsValid = true;
            bool MoreThanZeroPairs = false;
            while (RowsValid && row < C.FPIObject.FXUniqueCurrCount)
            {
                if (!(PairsInRowY(row) == 0 || PairsInRowY(row) == 2))
                {
                    RowsValid = false;
                }
                else
                {
                    if (PairsInRowY(row) == 2)
                        MoreThanZeroPairs = true;
                    row++;
                }
            }

            // return true if this combination is valid, i.e. > 0 symbols used and 2 pairs in every used row
            return RowsValid && MoreThanZeroPairs;
        }

        private int PairsInRowY(int RowY)
        {
            int Result = 0;
            for (int i = 0; i < C.FPIObject.FXUniqueCurrCount; i++)
            {
                if (PairsMatrix[i, RowY]) Result++;
            }

            return Result;
        }

        private int CurrencyIndex(string Currency)
        {
            for (int i = 0; i < C.FPIObject.FXUniqueCurrencies.Length; i++)
            {
                if (C.FPIObject.FXUniqueCurrencies[i] == Currency)
                    return i;
            }

            return -1;
        }

        internal string DecimalToStringBin(ulong DecimalNumber, int BinaryPositionsCount)
        {
            char[] StringBin = new char[BinaryPositionsCount];

            for (int i = C.FPIObject.FXSymsCount - 1; i > -1; i--)
            {
                if (DecimalNumber / KTools.Power(2, i) == 1)
                {
                    StringBin[i] = '1';
                }
                else
                {
                    StringBin[i] = '0';
                }
                DecimalNumber = DecimalNumber % KTools.Power(2, i);
            }

            string OutputString = "";
            for (int i = 0; i < StringBin.Length; i++)
            {
                OutputString += StringBin[i];
            }

            return KTools.ReverseString(OutputString.ToString());
        }

        private void SetUsedPairs(string NumericalOrderBinArray)
        {
            for (int i = 0; i < C.FPIObject.FXSymsCount; i++)
            {
                if (NumericalOrderBinArray[i] == '1')
                {
                    SetFXSymbolToUsed(C.FPIObject.FXUniqueSyms[i]);
                }
            }
        }

        private void SetFXSymbolToUsed(string FXSymbol)
        {
            int x = CurrencyIndex(KToolsFX.FirstCurrencyInFXSymbol(FXSymbol));
            int y = CurrencyIndex(KToolsFX.SecondCurrencyInFXSymbol(FXSymbol));
            PairsMatrix[x, y] = true;
            PairsMatrix[y, x] = true;
        }
    }
}