
Title: Hunter_v9e   Lots Size: 0.1
 	
Timeframe: All      Best Results Timeframe: M5  
	
Trading Pairs: All  Best Results With: EUR/USD    

Compatibility:	MT4 / MT5

Note: Put kernl320.dll file on libraries folder.


----------------------------------------------------

Input parameters:


Lots — a trading volume in standard lots.

StopLoss — a stop-loss to be used with trades.

TakeProfit — a take-profit to be used with trades.

TrailingStop — a trailing stop to be applied to trades.

Slippage — maximum tolerable slippage in pips.

Period_1 — the period of the first moving average.

Period_2 — the period of the second moving average.

Period_Sampling_Slow — the sampling period of the slow moving average.

Period_Sampling_Fast — the sampling period of the fast moving average.

MA_Method_Slow — the calculation method of the slow moving average.

MA_Method_Fast — the calculation method of the fast moving average.

MA_Applied_Price_Slow — the applied price for the slow moving average.

MA_Applied_Price_Fast — the applied price for the fast moving average.

MinDiff — a minimum difference between two moving averages in pips for the cross to count.

UseMM — if true, the EA will apply its money management rules.

LotsPer10000 — how many standard lots per trade to use if UseMM is set to true.

ECN_Mode — set it to true if your broker uses ECN execution.