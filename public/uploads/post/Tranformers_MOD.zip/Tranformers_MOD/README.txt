==============================
EA Transformers V3 MOD by nEk0
==============================
Copy these files to
Transformer_EA_V(3)_MOD.ex4 => MQL4\Experts
transformer_mod_setting.set => MQL4\Presets

Attach EA into chart and load settings. Change Lot Exponent only, know your best setting by backtesting first. These settings works well with XM Micro Account with min Equity of $5
Pair: EURUSD
TF: H1

Lots are calculated automatically based on your currently available equity. The formula is shown below:
Equity x Lot Exponent / 10000
By default minimum lot is 0.01 and maximum lot is 99, you can modify this according to your broker min and max lot.

Feel free to change all settings available and experiment with it. Share your settings with everyone.
Any comments and suggestions are welcomed.
==========================================================================

Support my work by opening an account on XM using link below.
http://clicks.pipaffiliates.com/afs/come.php?id=59&cid=44820&ctgid=17&atype=1

and apply for swap-free account using form below.
http://www.xm.com/islamic

In case you are interested to become XM web affiliate, register using link below.
http://clicks.pipaffiliates.com/afs/come.php?id=2827&cid=44889&atype=2&ctgid=0