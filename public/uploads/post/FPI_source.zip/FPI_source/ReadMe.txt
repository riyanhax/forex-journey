In the "precompiled" directory you will find a set of DLLs and an IDL indicator header. These files are ready to be copied directly to the NeoTicker/indicator folder and run.

Michal Kreslik
michal.kreslik@kreslik.com