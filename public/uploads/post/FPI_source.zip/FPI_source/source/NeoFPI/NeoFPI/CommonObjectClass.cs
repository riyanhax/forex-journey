﻿using System;
using System.Collections.Generic;
using System.Text;

using NeoTicker;
using KreslikLib.Neo;
using NeoFPI.Properties;
using System.Windows.Forms;

namespace NeoFPI
{
    public class CommonObject : IDisposable
    {
        internal PleaseWaitForm PleaseWait;
        internal Settings AppSettings;
        internal NeoEventsClass NeoEvents;
        internal ControlPanelForm ControlPanel;
        internal FPIObjectClass FPIObject;
        internal FPIToolsClass FPITools;
        internal NTIndicatorObjects N;

        public CommonObject()
        {
            PleaseWait = null;
            AppSettings = new Settings();
            NeoEvents = new NeoEventsClass();
            ControlPanel = null;
            FPIObject = new FPIObjectClass(this);
            FPITools = new FPIToolsClass(this);

            // register the events
            NeoEvents.FirstCalledWithObjectEvent += new FirstCalledWithObjectHandler(FPITools.PassTheNeoReference);
            NeoEvents.FirstCalledEvent += new FirstCalledHandler(FPITools.RefreshServices);
            NeoEvents.IDLCalledEvent += new IDLCalledHandler(FPITools.SetPlots);
        }

        public void Dispose()
        {
            PleaseWait.Dispose();
            NeoEvents.Dispose();
        }
    }
}
