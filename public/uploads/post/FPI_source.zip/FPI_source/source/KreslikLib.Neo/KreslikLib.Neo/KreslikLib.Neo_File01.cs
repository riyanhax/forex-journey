using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using NeoTicker;
using System.Collections;
using KreslikLib.Common;
using KreslikLib.Forex;

namespace KreslikLib.Neo
{
    public enum SymbolType
    {
        AllSymbols,
        ForexSymbols,
    }

    /// <summary>
    /// Static Neo Tools Class.
    /// </summary>
    public static class KToolsNeo
    {
        /// <summary>
        /// Extracts symbol array from a chart. SymbolType parameter switches between AllSymbols and ForexSymbols.
        /// If "ForexSymbols" is selected, it converts 6 and 7 chars FX symbols all to 7 chars FX symbols of the type
        /// "EUR/USD".
        /// </summary>
        /// <param name="NeoObjects">You must pass NeoObjects to this method.</param>
        /// <param name="ReturnSymbolType">Switches between All symbols and FX symbols only.</param>
        /// <param name="AllowDuplicity">Allows/disallows duplicity in the returned symbol array.</param>
        /// <param name="Sort">Sort alphabetically.</param>
        /// <returns></returns>
        public static void ExtractSymbolsFromChart(NTIndicatorObjects NeoObjects, SymbolType ReturnSymbolType, bool AllowDuplicity, bool Sort, out string[] ReturnSymbols, out int[] ReturnDataStreams)
        {
            ArrayList Symbols = new ArrayList();
            ArrayList DataStreams = new ArrayList();
            string CurrentSymbol;
            bool ThisSymbolIsNew;

            for (int i = 1; i <= NeoObjects.DataSeries().Count; i++)
            {
                CurrentSymbol = NeoObjects.DataSeries().get_Items(i).Symbol.ToString();

                switch (AllowDuplicity)
                {
                    case false:
                        ThisSymbolIsNew = true;
                        foreach (string SymbolItem in Symbols)
                        {
                            switch (ReturnSymbolType)
                            {
                                case SymbolType.AllSymbols:
                                    if (CurrentSymbol == SymbolItem) ThisSymbolIsNew = false;
                                    break;
                                case SymbolType.ForexSymbols:
                                    if (KToolsFX.ConvertFXSym6to7(CurrentSymbol) == SymbolItem) ThisSymbolIsNew = false;
                                    break;
                            }
                        }
                        if (ThisSymbolIsNew)
                        {
                            if (ReturnSymbolType == SymbolType.AllSymbols)
                            {
                                Symbols.Add(CurrentSymbol);
                                DataStreams.Add(i);
                            }
                            else if (ReturnSymbolType == SymbolType.ForexSymbols && KToolsFX.SymbolIsFXSymbol(CurrentSymbol))
                            {
                                CurrentSymbol = KToolsFX.ConvertFXSym6to7(CurrentSymbol);
                                Symbols.Add(CurrentSymbol);
                                DataStreams.Add(i);
                            }
                        }
                        break;
                    case true:
                        if (ReturnSymbolType == SymbolType.AllSymbols)
                        {
                            Symbols.Add(CurrentSymbol);
                            DataStreams.Add(i);
                        }
                        else if (ReturnSymbolType == SymbolType.ForexSymbols && KToolsFX.SymbolIsFXSymbol(CurrentSymbol))
                        {
                            CurrentSymbol = KToolsFX.ConvertFXSym6to7(CurrentSymbol);
                            Symbols.Add(CurrentSymbol);
                            DataStreams.Add(i);
                        }
                        break;
                }
            }

            ReturnSymbols = new string[Symbols.Count];
            ReturnDataStreams = new int[DataStreams.Count];

            Symbols.CopyTo(ReturnSymbols);
            DataStreams.CopyTo(ReturnDataStreams);

            if (Sort)
            {
                // Sorts Symbols and DataStreams on Symbols
                Array.Sort(ReturnSymbols, ReturnDataStreams);
            }
        }

        public static string[] ExtractAllSymbolsFromChart(NTIndicatorObjects NeoObjects)
        {
            string[] ReturnSymbols;
            int[] ReturnDataStreams;

            ExtractSymbolsFromChart(NeoObjects, SymbolType.AllSymbols, true, false, out ReturnSymbols, out ReturnDataStreams);

            return ReturnSymbols;
        }

        /// <summary>
        /// Causes the NeoTicker active window to refresh itself.
        /// </summary>
        public static void RefreshChart()
        {
            App MyNeoTickerApp = new App();
            ((FWTimeChart)MyNeoTickerApp.ActiveWindow).CompleteRecalc();
        }

        public static void RefreshChart(NTIndicatorObjects NeoObjects)
        {
            RefreshChart();
        }
    }
}